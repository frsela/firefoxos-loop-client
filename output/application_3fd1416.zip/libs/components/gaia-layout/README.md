# gaia layout

## Installation

```bash
$ bower install gaia-components/gaia-layout
```

## Description

This is just a simple css file, based on flexbox to help creating basic layout structures.
